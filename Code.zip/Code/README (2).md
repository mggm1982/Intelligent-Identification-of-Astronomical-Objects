# 🌌 Intelligent identification of Astronomical Objects

A supervised machine learning pipeline for classifying astronomical objects into **Stars**, **Galaxies**, and **Quasars** using photometric and spectroscopic observations from the Sloan Digital Sky Survey (SDSS).

---

## 📖 Overview

Modern astronomical surveys generate massive volumes of observational data, making manual classification of celestial objects infeasible. This project leverages machine learning techniques to automate the classification of astronomical objects based on their physical and observational characteristics.

The workflow includes:

* Data preprocessing
* Exploratory Data Analysis (EDA)
* Feature engineering
* Model development
* Performance evaluation
* Scientific interpretation

---

## 🎯 Objective

Develop a robust multi-class classification system capable of accurately distinguishing between:

| Class          | Description                                                                     |
| -------------- | ------------------------------------------------------------------------------- |
| ⭐ Star         | Self-luminous celestial object composed primarily of plasma                     |
| 🌌 Galaxy      | Large gravitationally bound system of stars, gas, dust, and dark matter         |
| ✨ Quasar (QSO) | Extremely luminous active galactic nucleus powered by a supermassive black hole |

---

## 📂 Dataset

**Source:** Sloan Digital Sky Survey (SDSS)

The dataset contains photometric and spectroscopic measurements of astronomical objects.

### Features

| Feature    | Description                               |
| ---------- | ----------------------------------------- |
| `alpha`    | Right Ascension (J2000 coordinate system) |
| `delta`    | Declination (J2000 coordinate system)     |
| `u`        | Ultraviolet photometric magnitude         |
| `g`        | Green photometric magnitude               |
| `r`        | Red photometric magnitude                 |
| `i`        | Near-infrared photometric magnitude       |
| `z`        | Infrared photometric magnitude            |
| `redshift` | Spectroscopic redshift measurement        |

### Target Variable

```text
STAR
GALAXY
QSO
```

---

## 🏗️ Project Workflow

```text
Raw Data
    │
    ▼
Data Cleaning
    │
    ▼
Exploratory Data Analysis
    │
    ▼
Feature Engineering
    │
    ▼
Train-Test Split
    │
    ▼
Model Training
    │
    ▼
Performance Evaluation
    │
    ▼
Model Comparison
    │
    ▼
Result Interpretation
```

---

## 🔬 Exploratory Data Analysis

The dataset was analyzed to understand feature distributions, relationships, and predictive significance.

### Analysis Performed

* Missing value inspection
* Statistical feature profiling
* Class distribution analysis
* Correlation matrix visualization
* Redshift distribution analysis
* Feature relationship exploration
* Dataset profiling using YData Profiling

### Key Observation

Redshift demonstrates strong discriminative power for distinguishing stellar objects from galaxies and quasars.

---

## ⚙️ Data Preprocessing

The following preprocessing steps were performed:

* Removal of non-informative metadata attributes
* Feature selection
* Label encoding of target classes
* Train-test split
* Feature scaling for linear models

---

## 🧠 Feature Engineering

Feature selection was guided by both astrophysical significance and predictive utility.

### Photometric Features

```text
u, g, r, i, z
```

These magnitudes capture the spectral energy distribution of astronomical objects across multiple wavelength bands.

### Spectroscopic Feature

```text
redshift
```

Redshift serves as a direct indicator of distance and recessional velocity, making it one of the most informative variables for celestial object classification.

---

## 🤖 Machine Learning Models

The following supervised learning algorithms were implemented and compared:

### Logistic Regression

Linear baseline classifier used to establish reference performance.

### Decision Tree Classifier

Non-linear tree-based model capable of learning hierarchical decision boundaries.

### Random Forest Classifier

Ensemble learning algorithm that combines multiple decision trees to improve generalization and reduce overfitting.

### XGBoost Classifier

Gradient boosting framework optimized for predictive performance and robustness.

---

## 📊 Evaluation Metrics

Model performance was evaluated using:

* Accuracy Score
* Precision
* Recall
* F1 Score
* Classification Report
* Confusion Matrix

---

## 📈 Results

### Key Findings

* Redshift is the most discriminative feature for object classification.
* Photometric magnitudes effectively capture spectral differences among celestial object classes.
* Ensemble methods outperform linear models by capturing complex non-linear relationships.
* Random Forest and XGBoost achieve superior classification performance.



---

## 🛠️ Technology Stack

### Programming Language

* Python

### Data Processing

* Pandas
* NumPy

### Data Visualization

* Matplotlib
* Seaborn

### Machine Learning

* Scikit-Learn
* XGBoost

### Data Profiling

* YData Profiling

### Development Environment

* Jupyter Notebook

---

## 👨‍💻 Author

**Mohit Trivedi**
Undergraduate Student, IIT Roorkee

